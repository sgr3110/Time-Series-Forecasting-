# 🔧 firebase_config.py
import pyrebase

firebase_config = {
    "apiKey": "AIzaSyBg8HSYkcrhvA1zOsv7XOcrQlH3uwfw2sc",
    "authDomain": "stockforecasting1107.firebaseapp.com",
    "projectId": "stockforecasting1107",
    "storageBucket": "stockforecasting1107.appspot.com",
    "messagingSenderId": "528666678237",
    "appId": "1:528666678237:web:0c4958b6dacf2898fc5c34",
    "measurementId": "G-FTJXP4QP4R",
    "databaseURL": "https://stockforecasting1107-default-rtdb.firebaseio.com"
}

firebase = pyrebase.initialize_app(firebase_config)
auth = firebase.auth()
db = firebase.database()
